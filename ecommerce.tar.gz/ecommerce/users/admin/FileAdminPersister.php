<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include_once(__DIR__ . '/AdminPersister.php');
include_once(__DIR__ . '/AdminUser.php');

class FileAdminPersister implements AdminPersister {
	const FILE_NAME = 'admins.txt';

	public function create(string $username, string $password, string $fullName, string $address, string $email, int $contactNumber, int $VISA){
		$failePath = __DIR__ .'/db/' . self::FILE_NAME;
		$file = fopen($failePath,"a") or die ("Error. File Not found...");

		$newAdmin = new Admin($username, $password, $fullName, $address, $email, $contactNumber, $VISA);
		fwrite($file, $newAdmin->__toString());
		fclose($file);
	}

	public function update(string $username, string $password, string $fullName, string $address, string $email, int $contactNumber, int $VISA){
		$admins = $this->getAll();

		$failePath = __DIR__ .'/db/' . self::FILE_NAME;
		$file = fopen($failePath,"w") or die ("Error. File Not found...");
		
		file_put_contents($failePath, "");

		foreach($admins as $admin) {
			if ($admin->username() === $username) {
				$admin->setUsername($username);
				$admin->setPassword($password);
				$admin->setFullName($fullName);
				$admin->setAddress($address);
				$admin->setEmail($email);
				$admin->setContactNumber($contactNumber);
				$admin->setVISA($VISA);				
			}
			fwrite($file, $admin->__toString());
		}
		fclose($file);
	}
	
	public function delete(string $username) {
		$admins = $this->getAll();

		$failePath = __DIR__ .'/db/' . self::FILE_NAME;
		$file = fopen($failePath,"w") or die ("Error. File Not found...");

		file_put_contents($failePath, "");

		foreach($admins as $admin) {
			if ($admin->username() !== $username) {
				fwrite($file, $admin->__toString());
			}
		}

		fclose($file);
	}

	public function getAll() {
		$failePath = __DIR__.'/db/' . self::FILE_NAME;
		$file = fopen($failePath,"r") or die ("Error. File Not found...");

		if ($file) {
			$mida_fitxer=filesize($failePath);
			if (empty($mida_fitxer)) {
				return [];
			}
			$lines = explode(PHP_EOL, fread($file, $mida_fitxer));//separa les linees i les posa en un array
		}

		$admins = [];//array amb cada producte
		foreach ($lines as $line) {//per cada linea de un producte
			$adminsAttributes = explode('-', $line);//separa els atributs i els guarda en un array
			if (isset($adminsAttributes[0]) && isset($adminsAttributes[1]) && isset($adminsAttributes[2]) && isset($adminsAttributes[3]) && isset($adminsAttributes[4]) && isset($adminsAttributes[5]) && isset($adminsAttributes[6])) {
				$admins[] = new Admin(
					$adminsAttributes[0],
					$adminsAttributes[1],
					$adminsAttributes[2],
					$adminsAttributes[3],
					$adminsAttributes[4],
					(int)$adminsAttributes[5],
					(int)$adminsAttributes[6]
				);
			}
		}

		fclose($file);
		return $admins;
	}
}
