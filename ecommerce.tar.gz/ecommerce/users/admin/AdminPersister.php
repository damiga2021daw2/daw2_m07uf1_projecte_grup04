<?php

interface AdminPersister {
	public function create(string $username, string $password, string $fullName, string $address, string $email, int $contactNumber, int $VISA);
	public function update(string $username, string $password, string $fullName, string $address, string $email, int $contactNumber, int $VISA);
	public function delete(string $username);
	public function getAll();
}
