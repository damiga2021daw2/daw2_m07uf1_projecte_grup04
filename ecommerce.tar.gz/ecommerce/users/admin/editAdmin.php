<?php
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);

	include_once(__DIR__ . '/FileAdminPersister.php');

	$persister = new FileAdminPersister();
	
	if ($_SERVER["REQUEST_METHOD"] === "POST") {
		if(isset($_POST["username"]) && (isset($_POST["_method"]) && $_POST["_method"] === "delete")) {
			$persister->delete((int)$_POST["username"]);
			echo "<h1>Deleted</h1> <br>";
			echo ("<a href=\"/ecommerce/\">Back to list</a>");
			return;
		}
	}

	if ($_SERVER["REQUEST_METHOD"] === "POST") {
		if (isset($_POST["username"]) && isset($_POST["password"]) && isset($_POST["fullName"]) && isset($_POST["address"]) && isset($_POST["email"]) && isset($_POST["contactNumber"]) && isset($_POST["VISA"]) ){
			$persister->update($_POST["username"] ,$_POST["password"], $_POST["fullName"], $_POST["address"], $_POST["email"], (int)$_POST["contactNumber"], (int)$_POST["VISA"]);
		}
	}

	$admins = $persister->getAll();
	$adminId = (int)$_GET['username'] ?? (int) $_POST['username'];
	$selectedAdmin;

	foreach($admins as $admin) {
		if ($adminId === $admin->username()) {
			$selectedAdmin = $admin;
		}
	}
?>


<h1>Edit</h1>
<a href="/ecommerce/">Back to list</a>
<form method="post">
	<input type="text" name="username" placeholder="username"></input>
	<input type="text" name="password" placeholder="password"></input>
	<input type="text" name="fullName" placeholder="full name"></input>
	<input type="text" name="address" placeholder="address"></input>
	<input type="text" name="email" placeholder="email"></input>
	<input type="number" name="contactNumber" placeholder="contact number"></input>
	<input type="number" name="VISA" placeholder="VISA"></input>
	<button type="submit" name="edit">Edit</button>
</form>

<form method="post">
	<input type="text" name="username" placeholder="username" value="<?php echo $selectedAdmin->username() ?>" hidden></input>
	<input type="text" name="_method" value="delete" hidden></input>
	<button type="submit" name="delete">Delete</button>
</form>
