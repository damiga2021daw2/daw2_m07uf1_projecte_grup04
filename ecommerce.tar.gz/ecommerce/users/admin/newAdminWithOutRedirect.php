<?php
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);

	include_once(__DIR__ . '/FileAdminPersister.php');

	$result = "Waiting for data...";

	function createNewAdmin(string $username, string $password, string $fullName, string $address, string $email, int $contactNumber, int $VISA) {
		$persister = new FileAdminPersister();
		$persister->create($username, $password, $fullName, $address, $email, $contactNumber, $VISA);
	}

	if ($_SERVER["REQUEST_METHOD"] === "POST") {
		if (isset($_POST["username"]) && isset($_POST["password"]) && isset($_POST["fullName"]) && isset($_POST["address"]) && isset($_POST["email"]) && isset($_POST["contactNumber"]) && isset($_POST["VISA"]) ) {
			createNewAdmin($_POST["username"] ,$_POST["password"], $_POST["fullName"], $_POST["address"], $_POST["email"], (int)$_POST["contactNumber"], (int)$_POST["VISA"]);
			$result = "Success...";
		} else {
			$result = "Ops... Something wrong happened...";
		}
	}
?>

<h1>Create new admin</h1>
<a href="/ecommerce/">Back to list</a>
<form method="post">
	<input type="text" name="username" placeholder="username"></input>
	<input type="text" name="password" placeholder="password"></input>
	<input type="text" name="fullName" placeholder="full name"></input>
	<input type="text" name="address" placeholder="address"></input>
	<input type="text" name="email" placeholder="email"></input>
	<input type="number" name="contactNumber" placeholder="contact number"></input>
	<input type="number" name="VISA" placeholder="VISA"></input>
	<button type="submit" name="submit">Create</button>
</form>
<?php echo $result; ?>
