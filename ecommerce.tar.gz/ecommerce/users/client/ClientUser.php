<?php

class Client {
	private $username;
	private $password;
	private $fullName;
	private $address;
	private $email;
	private $contactNumber;
	private $VISA;

	public function __construct(
		string $username,
		string $password,
		string $fullName,
		string $address,
		string $email,
		int $contactNumber,
		int $VISA
	) {
		$this->username = $username;
		$this->password = $password;
		$this->fullName = $fullName;
		$this->address = $address;
		$this->email = $email;
		$this->contactNumber = $contactNumber;
		$this->VISA = $VISA;
	}

	public function username(): string{
		return $this->username;
	}
	
	public function setUsername($n){
		$this->username = $n;
	}
	
	

	public function password(): string{
		return $this->password;
	}

	public function setPassword($p){
		$this->password = $p;
	}
	
	
	
	public function fullName(): string{
		return $this->fullName;
	}

	public function setFullName($fn){
		$this->fullName = $fn;
	}
	
	
	
	public function address(): string{
		return $this->address;
	}

	public function setAddress($add){
		$this->address = $add;
	}
	
	
	
	public function email(): string{
		return $this->email;
	}

	public function setEmail($e){
		$this->email = $e;
	}
	
	
	
	public function contactNumber(): int{
		return $this->contactNumber;
	}

	public function setContactNumber($cn){
		$this->contactNumber = $cn;
	}
	
	
	
	public function VISA(): int{
		return $this->VISA;
	}

	public function setVISA($v){
		$this->VISA = $v;
	}
	
	

	public function __toString(){
		return $this->username ."-".$this->password."-".$this->fullName."-".$this->address."-".$this->email."-".$this->contactNumber."-".$this->VISA."\n";
	}
}
?>
