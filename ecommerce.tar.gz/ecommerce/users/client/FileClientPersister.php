<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include_once(__DIR__ . '/ClientPersister.php');
include_once(__DIR__ . '/ClientUser.php');

class FileClientPersister implements ClientPersister {
	const FILE_NAME = 'clients.txt';

	public function create(string $username, string $password, string $fullName, string $address, string $email, int $contactNumber, int $VISA){
		$failePath = __DIR__ .'/db/' . self::FILE_NAME;
		$file = fopen($failePath,"a") or die ("Error. File Not found...");

		$newClient = new Client($username, $password, $fullName, $address, $email, $contactNumber, $VISA);
		fwrite($file, $newClient->__toString());
		fclose($file);
	}

	public function update(string $username, string $password, string $fullName, string $address, string $email, int $contactNumber, int $VISA){
		$clients = $this->getAll();

		$failePath = __DIR__ .'/db/' . self::FILE_NAME;
		$file = fopen($failePath,"w") or die ("Error. File Not found...");
		
		file_put_contents($failePath, "");

		foreach($clients as $client) {
			if ($client->username() === $username) {
				$client->setUsername($username);
				$client->setPassword($password);
				$client->setFullName($fullName);
				$client->setAddress($address);
				$client->setEmail($email);
				$client->setContactNumber($contactNumber);
				$client->setVISA($VISA);				
			}
			fwrite($file, $client->__toString());
		}
		fclose($file);
	}
	
	public function delete(string $username) {
		$clients = $this->getAll();

		$failePath = __DIR__ .'/db/' . self::FILE_NAME;
		$file = fopen($failePath,"w") or die ("Error. File Not found...");

		file_put_contents($failePath, "");

		foreach($clients as $client) {
			if ($client->username() !== $username) {
				fwrite($file, $client->__toString());
			}
		}

		fclose($file);
	}

	public function getAll() {
		$failePath = __DIR__.'/db/' . self::FILE_NAME;
		$file = fopen($failePath,"r") or die ("Error. File Not found...");

		if ($file) {
			$mida_fitxer=filesize($failePath);
			if (empty($mida_fitxer)) {
				return [];
			}
			$lines = explode(PHP_EOL, fread($file, $mida_fitxer));//separa les linees i les posa en un array
		}

		$clients = [];//array amb cada producte
		foreach ($lines as $line) {//per cada linea de un producte
			$clientsAttributes = explode('-', $line);//separa els atributs i els guarda en un array
			if (isset($clientsAttributes[0]) && isset($clientsAttributes[1]) && isset($clientsAttributes[2]) && isset($clientsAttributes[3]) && isset($clientsAttributes[4]) && isset($clientsAttributes[5]) && isset($clientsAttributes[6])) {
				$clients[] = new Client(
					$clientsAttributes[0],
					$clientsAttributes[1],
					$clientsAttributes[2],
					$clientsAttributes[3],
					$clientsAttributes[4],
					(int)$clientsAttributes[5],
					(int)$clientsAttributes[6]
				);
			}
		}

		fclose($file);
		return $clients;
	}
}
