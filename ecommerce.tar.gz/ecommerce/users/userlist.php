<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include_once (__DIR__ . '/client/FileClientPersister.php');
include_once (__DIR__ . '/admin/FileAdminPersister.php');


$clientPersister = new FileClientPersister();
$adminPersister = new FileAdminPersister();


$clients = $clientPersister->getAll();
$admins = $adminPersister->getAll();

?>

<html>
	<body>
		<h1>Userlist: </h1>	
		<div style="border: 1px black solid;">
		<a href="/ecommerce/users/client/newClientWithOutRedirect.php">Create new client</a><br>
			<h2>Clients:</h2>
			<table>
			  <tr>
				<th>Username</th>
				<th>Password</th>
				<th>Full Name</th>
				<th>Address</th>
				<th>Email</th>
				<th>Contact Number</th>
				<th>VISA</th>
				<th></th>
			  </tr>
			  <?php
				foreach($clients as $client) {
					echo "<tr>";
						echo "<td>".$client->username()."</td>";
						echo "<td>".$client->password()."</td>";
						echo "<td>".$client->fullName()."</td>";
						echo "<td>".$client->address()."</td>";
						echo "<td>".$client->email()."</td>";
						echo "<td>".$client->contactNumber()."</td>";
						echo "<td>".$client->VISA()."</td>";
						echo "<td><a href=\"/ecommerce/users/client/editClient.php?id=".$client->username()."\">Edit<a/></td>";
					echo "</tr>";
				}
			  ?>
			</table>
		</div><br>
		
		<div style="border: 1px black solid;">
		<a href="/ecommerce/users/admin/newAdminWithOutRedirect.php">Create new admin</a><br>
			<h2>Admins:</h2>
			<table>
			  <tr>
				<th>Username</th>
				<th>Password</th>
				<th>Full Name</th>
				<th>Address</th>
				<th>Email</th>
				<th>Contact Number</th>
				<th>VISA</th>
				<th></th>
			  </tr>
			  <?php
				foreach($admins as $admin) {
					echo "<tr>";
						echo "<td>".$admin->username()."</td>";
						echo "<td>".$admin->password()."</td>";
						echo "<td>".$admin->fullName()."</td>";
						echo "<td>".$admin->address()."</td>";
						echo "<td>".$admin->email()."</td>";
						echo "<td>".$admin->contactNumber()."</td>";
						echo "<td>".$admin->VISA()."</td>";
						echo "<td><a href=\"/ecommerce/users/admin/editAdmin.php?id=".$admin->username()."\">Edit<a/></td>";
					echo "</tr>";
				}
			  ?>
			</table>
		</div>
	</body>
</html>
