<?php
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);
	
	include_once(__DIR__ . '/users/client/FileClientPersister.php');
	include_once(__DIR__ . '/users/admin/FileAdminPersister.php');
	

	
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);


	function redirect(string $username, string $password) {
		$clientPersister = new FileClientPersister();
		$clients = $clientPersister->getAll();
		
		$adminPersister = new FileAdminPersister();
		$admins = $adminPersister->getAll();

		foreach($clients as $client) {
			if(($username == $client->username()) && ($password == $client->password())){
				header('Location: http://localhost/ecommerce/shoppingCart/index.php');
			}
		}
		
		foreach($admins as $admin) {
			if(($username == $admin->username()) && ($password == $admin->password())){
				header('Location: http://localhost/ecommerce/products/index.php');
			}
		}


		/*if($username == "admin" && $password == "Qwerty_1"){
			header('Location: http://localhost/ecommerce/products/index.php');
		}
		
		if($username == "client1" && $password == "Qwerty_2"){
			header('Location: http://localhost/ecommerce/shoppingCart/index.php');
		}*/
	}

	if ($_SERVER["REQUEST_METHOD"] === "POST") {
		if(isset($_POST["username"]) && isset($_POST["password"])) {
			redirect($_POST["username"] ,$_POST["password"]);
		}
	}
?>

<h1>Ecommerce</h1>
<form method="POST">
	<font face="Arial">
		<br>
		Username: <input type="text" name="username"><br> 
		Password: <input type="password" name="password"><br> 
		<button type="submit" name="login">Login</button>
	</font>
</form>

<a href="/ecommerce/users/client/newClientWithOutRedirect.php">Create new client</a><br>
<a href="/ecommerce/users/admin/newAdminWithOutRedirect.php">Create new admin</a><br><br>
<a href="/ecommerce/users/userlist.php">View UserList</a>


