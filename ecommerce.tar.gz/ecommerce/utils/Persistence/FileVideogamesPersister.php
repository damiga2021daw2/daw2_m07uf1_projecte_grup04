<?php
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);

	include_once(__DIR__ . '/VideogamesPersister.php');
	include_once(__DIR__ . '/../../products/Videogames.php');

	class FileVideogamesPersister implements VideogamesPersister {
		const FILE_NAME = 'videogames.txt';

		public function createVideogames(int $id, string $name, float $price, string $description, string $company){
			$failePath = __DIR__ .'/db/' . self::FILE_NAME;
			$file = fopen($failePath,"a") or die ("Error. File Not found...");

			$newVideogames = new Videogames($id, $name, $price, $description, $company);
			fwrite($file, $newVideogames->__toString());
			fclose($file);
		}

		public function updateVideogames(int $id, string $name, float $price, string $description, string $company){
			$Videogames = $this->getAllVideogames();

			$failePath = __DIR__ .'/db/' . self::FILE_NAME;
			$file = fopen($failePath,"w") or die ("Error. File Not found...");
			
			file_put_contents($failePath, "");

			foreach($Videogames as $Videogames) {
				if ($Videogames->id() === $id) {
					$Videogames->setName($name);
					$Videogames->setPrice($price);
					$Videogames->setDescription($description);
					$Videogames->setCompany($company);
				}
				fwrite($file, $Videogames->__toString());
			}

			fclose($file);
		}

		public function deleteVideogames(int $id) {
			$Videogames = $this->getAllVideogames();

			$failePath = __DIR__ .'/db/' . self::FILE_NAME;
			$file = fopen($failePath,"w") or die ("Error. File Not found...");

			file_put_contents($failePath, "");

			foreach($Videogames as $Videogames) {
				if ($Videogames->id() !== $id) {
					fwrite($file, $Videogames->__toString());
				}
			}

			fclose($file);
		}

		public function getAllVideogames() {
			$failePath = __DIR__.'/db/' . self::FILE_NAME;
			$file = fopen($failePath,"r") or die ("Error. File Not found...");

			if ($file) {
				$mida_fitxer=filesize($failePath);
				if (empty($mida_fitxer)) {
					return [];
				}
				$lines = explode(PHP_EOL, fread($file, $mida_fitxer));//separa les linees i les posa en un array
			}

			$Videogames = [];//array amb cada producte
			foreach ($lines as $line) {//per cada linea de un producte
				$VideogamesAttributes = explode('-', $line);//separa els atributs i els guarda en un array
				if (isset($VideogamesAttributes[0]) && isset($VideogamesAttributes[1]) && isset($VideogamesAttributes[2]) && isset($VideogamesAttributes[3]) && isset($VideogamesAttributes[4])) {
					$Videogames[] = new Videogames(
						(int)$VideogamesAttributes[0],
						$VideogamesAttributes[1],
						(int)$VideogamesAttributes[2],
						$VideogamesAttributes[3],
						$VideogamesAttributes[4]
					);
				}
			}

			fclose($file);
			return $Videogames;
		}
	}
?>
