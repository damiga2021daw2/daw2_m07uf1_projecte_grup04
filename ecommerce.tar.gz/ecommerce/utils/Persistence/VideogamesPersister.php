<?php

interface VideogamesPersister {
	public function createVideogames(int $id, string $name, float $price, string $description, string $company);
	public function updateVideogames(int $id, string $name, float $price, string $description, string $company);
	public function deleteVideogames(int $id);
	public function getAllVideogames();
}
