<?php

include_once(__DIR__ . '/../../products/Product.php');

function createProduct(int $id, string $name, float $price, string $description){
	$failePath = __DIR__ .'/db/products.txt';
	$file = fopen($failePath,"a") or die ("Error. File Not found...");

	$newProduct = new Product($id, $name, $price, $description);
	fwrite($file, $newProduct->__toString());
	fclose($file);
}

