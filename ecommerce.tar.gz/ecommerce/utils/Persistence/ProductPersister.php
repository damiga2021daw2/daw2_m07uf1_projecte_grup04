<?php

interface ProductPersister {
	public function create(int $id, string $name, float $price, string $description);
	public function update(int $id, string $name, float $price, string $description);
	public function delete(int $id);
	public function getAll();
}
