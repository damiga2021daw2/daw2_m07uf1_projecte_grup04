<?php

interface ClothingPersister {
	public function createClothing(int $id, string $name, float $price, string $description, string $textilType);
	public function updateClothing(int $id, string $name, float $price, string $description, string $textilType);
	public function deleteClothing(int $id);
	public function getAllClothing();
}
