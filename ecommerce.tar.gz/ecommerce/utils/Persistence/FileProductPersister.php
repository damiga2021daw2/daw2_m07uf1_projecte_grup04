<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include_once(__DIR__ . '/ProductPersister.php');
include_once(__DIR__ . '/../../products/Product.php');

class FileProductPersister implements ProductPersister {
	const FILE_NAME = 'products.txt';

	public function create(int $id, string $name, float $price, string $description){
		$failePath = __DIR__ .'/db/' . self::FILE_NAME;
		$file = fopen($failePath,"a") or die ("Error. File Not found...");

		$newProduct = new Product($id, $name, $price, $description);
		fwrite($file, $newProduct->__toString());
		fclose($file);
	}

	public function update(int $id, string $name, float $price, string $description){
		$products = $this->getAll();

		$failePath = __DIR__ .'/db/' . self::FILE_NAME;
		$file = fopen($failePath,"w") or die ("Error. File Not found...");
		
		file_put_contents($failePath, "");

		foreach($products as $product) {
			if ($product->id() === $id) {
				$product->setName($name);
				$product->setPrice($price);
				$product->setDescription($description);
			}
			fwrite($file, $product->__toString());
		}

		fclose($file);
	}
	
	public function delete(int $id) {
		$products = $this->getAll();

		$failePath = __DIR__ .'/db/' . self::FILE_NAME;
		$file = fopen($failePath,"w") or die ("Error. File Not found...");

		file_put_contents($failePath, "");

		foreach($products as $product) {
			if ($product->id() !== $id) {
				fwrite($file, $product->__toString());
			}
		}

		fclose($file);
	}

	public function getAll() {
		$failePath = __DIR__.'/db/' . self::FILE_NAME;
		$file = fopen($failePath,"r") or die ("Error. File Not found...");

		if ($file) {
			$mida_fitxer=filesize($failePath);
			if (empty($mida_fitxer)) {
				return [];
			}
			$lines = explode(PHP_EOL, fread($file, $mida_fitxer));//separa les linees i les posa en un array
		}

		$products = [];//array amb cada producte
		foreach ($lines as $line) {//per cada linea de un producte
			$productAttributes = explode('-', $line);//separa els atributs i els guarda en un array
			if (isset($productAttributes[0]) && isset($productAttributes[1]) && isset($productAttributes[2]) && isset($productAttributes[3])) {
				$products[] = new Product(
					(int)$productAttributes[0],
					$productAttributes[1],
					(int)$productAttributes[2],
					$productAttributes[3]
				);
			}
		}

		fclose($file);
		return $products;
	}
}
