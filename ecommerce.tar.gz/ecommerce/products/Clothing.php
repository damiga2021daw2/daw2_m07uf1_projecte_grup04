<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include_once(__DIR__ . '/Product.php');

class Clothing extends Product{
	private $textilType;

	public function __construct(int $id, string $name, float $price, string $description, string $textilType) {
		parent::__construct($id, $name, $price, $description);
		$this->textilType = $textilType;
	}

	public function id(): int{
		return $this->id;
	}

	public function name(): string{
		return $this->name;
	}

	public function setName($n){
		$this->name = $n;
	}

	public function price(): float{
		return $this->price;
	}
	
	public function setPrice($p){
		$this->price = $p;
	}

	public function description(): string{
		return $this->description;
	}
	
	public function setDescription($d){
		$this->description = $d;
	}
	
	public function textilType(): string{
		return $this->textilType;
	}
	
	public function setTextilType($tT){
		$this->textilType = $tT;
	}

	public function __toString(){
		return $this->id ."-".$this->name."-".$this->price."-".$this->description."-".$this->textilType."\n";
	}
}
?>
