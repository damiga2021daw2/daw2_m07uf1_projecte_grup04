<?php
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);
		
	include_once (__DIR__ . '/../../utils/Persistence/FileClothingPersister.php');

	$result = "Waiting for data...";

	function createNewClothing(int $id, string $name, float $price, string $description, string $textilType) {
		$persister = new FileClothingPersister();
		$persister->createClothing($id, $name, $price, $description, $textilType);
	}

	if ($_SERVER["REQUEST_METHOD"] === "POST") {
		if (isset($_POST["id"]) && isset($_POST["name"]) && isset($_POST["price"]) && isset($_POST["description"]) && isset($_POST["textilType"])) {
			createNewClothing((int)$_POST["id"] ,$_POST["name"], (float)$_POST["price"], $_POST["description"], $_POST["textilType"]);
			$result = "Success...";
		} else {
			$result = "Ops... Something wrong happened...";
		}
	}
?>

<h1>Creating new Clothing Product</h1>
<a href="/ecommerce/products/">Back to list</a>
<form method="post">
	<input type="number" name="id" placeholder="id"></input>
	<input type="text" name="name" placeholder="Name"></input>
	<input type="number" name="price" placeholder="price"></input>
	<textarea name="description" placeholder="Write something good..."></textarea>
	<input type="text" name="textilType" placeholder="Textil Type"></input>
	<button type="submit" name="submit">Create</button>
</form>
<?php echo $result; ?>
