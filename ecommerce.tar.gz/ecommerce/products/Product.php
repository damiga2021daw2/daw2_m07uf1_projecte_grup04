<?php

class Product {
	protected $id;
	protected $name;
	protected $price;
	protected $description;

	public function __construct(
		int $id,
		string $name,
		float $price,
		string $description
	) {
		$this->id = $id;
		$this->name = $name;
		$this->price = $price;
		$this->description = $description;
	}

	public function id(): int{
		return $this->id;
	}

	public function name(): string{
		return $this->name;
	}

	public function setName($n){
		$this->name = $n;
	}

	public function price(): float{
		return $this->price;
	}
	
	public function setPrice($p){
		$this->price = $p;
	}

	public function description(): string{
		return $this->description;
	}
	
	public function setDescription($d){
		$this->description = $d;
	}

	public function __toString(){
		return $this->id ."-".$this->name."-".$this->price."-".$this->description."\n";
	}
}
?>
