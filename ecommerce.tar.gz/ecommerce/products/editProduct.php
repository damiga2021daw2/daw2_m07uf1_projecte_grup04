<?php
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);

	include_once (__DIR__ . '/../utils/Persistence/FileProductPersister.php');

	$persister = new FileProductPersister();
	
	if ($_SERVER["REQUEST_METHOD"] === "POST") {
		if(isset($_POST["id"]) && (isset($_POST["_method"]) && $_POST["_method"] === "delete")) {
			$persister->delete((int)$_POST["id"]);
			echo "<h1>Deleted</h1> <br>";
			echo ("<a href=\"/ecommerce/products/\">Back to list</a>");
			return;
		}
	}

	if ($_SERVER["REQUEST_METHOD"] === "POST") {
		if(isset($_POST["id"]) && isset($_POST["name"]) && isset($_POST["price"]) && isset($_POST["description"])) {
			$persister->update((int)$_POST["id"], $_POST["name"], (float)$_POST["price"], $_POST["description"]);
		}
	}

	$products = $persister->getAll();
	$productId = (int)$_GET['id'] ?? (int) $_POST['id'];
	$selectedProduct;

	foreach($products as $product) {
		if ($productId === $product->id()) {
			$selectedProduct = $product;
		}
	}
?>


<h1>Edit</h1>
<a href="/ecommerce/products/">Back to list</a>
<form method="post">
	<input type="number" name="id" placeholder="id" value="<?php echo $selectedProduct->id() ?>" hidden></input>
	<input type="text" name="name" placeholder="Name" value="<?php echo $selectedProduct->name() ?>"></input>
	<input type="number" name="price" placeholder="price" value="<?php echo $selectedProduct->price() ?>"></input>
	<textarea name="description" placeholder="Write something good..."><?php echo $selectedProduct->description() ?></textarea>
	<button type="submit" name="edit">Edit</button>
</form>

<form method="post">
	<input type="number" name="id" placeholder="id" value="<?php echo $selectedProduct->id() ?>" hidden></input>
	<input type="text" name="_method" value="delete" hidden></input>
	<button type="submit" name="delete">Delete</button>
</form>
