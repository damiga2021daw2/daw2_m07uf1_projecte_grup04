<?php
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);

	include_once (__DIR__ . '/addingToTheChart.php');

	$persister = new FileClothingPersister();

	if ($_SERVER["REQUEST_METHOD"] === "POST") {
		if(isset($_POST["id"]) && (isset($_POST["_method"]) && $_POST["_method"] === "delete")) {
			$persister->deleteClothing((int)$_POST["id"]);
			echo "<h1>Deleted</h1> <br>";
			echo ("<a href=\"/ecommerce/products/\">Back to list</a>");
			return;
		}
	}

	if ($_SERVER["REQUEST_METHOD"] === "POST") {
		if(isset($_POST["id"]) && isset($_POST["name"]) && isset($_POST["price"]) && isset($_POST["description"]) && isset($_POST["textilType"])) {
			$persister->updateClothing((int)$_POST["id"], $_POST["name"], (float)$_POST["price"], $_POST["description"], $_POST["textilType"]);
		}
	}

	$clothings = $persister->getAllClothing();
	$clothingId = (int)$_GET['id'] ?? (int) $_POST['id'];
	$selectedClothing;

	foreach($clothings as $clothing) {
		if ($clothingId === $clothing->id()) {
			$selectedClothing = $clothing;
		}
	}
?>


<h1>Edit</h1>
<a href="/ecommerce/products/">Back to list</a>
<form method="post">
	<input type="number" name="id" placeholder="id" value="<?php echo $selectedClothing->id() ?>" hidden></input>
	<input type="text" name="name" placeholder="Name" value="<?php echo $selectedClothing->name() ?>"></input>
	<input type="number" name="price" placeholder="price" value="<?php echo $selectedClothing->price() ?>"></input>
	<textarea name="description" placeholder="Write something good..."><?php echo $selectedClothing->description() ?></textarea>
	<input type="text" name="textilType" placeholder="Textil Type" value="<?php echo $selectedClothing->textilType() ?>"></input>
	<button type="submit" name="edit">Edit</button>
</form>

<form method="post">
	<input type="number" name="id" placeholder="id" value="<?php echo $selectedClothing->id() ?>" hidden></input>
	<input type="text" name="_method" value="delete" hidden></input>
	<button type="submit" name="delete">Delete</button>
</form>
