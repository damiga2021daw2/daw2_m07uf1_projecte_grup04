<?php
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);

	include_once(__DIR__ . '/../products/Clothing.php');

	class FileClothingPersister implements ClothingPersister {
		const FILE_NAME = 'clothings.txt';

		public function createClothing(int $id, string $name, float $price, string $description, string $textilType){
			$failePath = __DIR__ .'/db/' . self::FILE_NAME;
			$file = fopen($failePath,"a") or die ("Error. File Not found...");

			$newClothing = new Clothing($id, $name, $price, $description, $textilType);
			fwrite($file, $newClothing->__toString());
			fclose($file);
		}

		public function updateClothing(int $id, string $name, float $price, string $description, string $textilType){
			$clothings = $this->getAllClothing();

			$failePath = __DIR__ .'/db/' . self::FILE_NAME;
			$file = fopen($failePath,"w") or die ("Error. File Not found...");
			
			file_put_contents($failePath, "");

			foreach($clothings as $clothing) {
				if ($clothing->id() === $id) {
					$clothing->setName($name);
					$clothing->setPrice($price);
					$clothing->setDescription($description);
					$clothing->setTextilType($textilType);
				}
				fwrite($file, $clothing->__toString());
			}

			fclose($file);
		}
		
		public function deleteClothing(int $id) {
			$clothings = $this->getAllClothing();

			$failePath = __DIR__ .'/db/' . self::FILE_NAME;
			$file = fopen($failePath,"w") or die ("Error. File Not found...");

			file_put_contents($failePath, "");

			foreach($clothings as $clothing) {
				if ($clothing->id() !== $id) {
					fwrite($file, $clothing->__toString());
				}
			}

			fclose($file);
		}
		
		public function getAllClothing() {
			$failePath = __DIR__.'/db/' . self::FILE_NAME;
			$file = fopen($failePath,"r") or die ("Error. File Not found...");

			if ($file) {
				$mida_fitxer=filesize($failePath);
				if (empty($mida_fitxer)) {
					return [];
				}
				$lines = explode(PHP_EOL, fread($file, $mida_fitxer));//separa les linees i les posa en un array
			}

			$clothings = [];//array amb cada producte
			foreach ($lines as $line) {//per cada linea de un producte
				$clothingAttributes = explode('-', $line);//separa els atributs i els guarda en un array
				if (isset($clothingAttributes[0]) && isset($clothingAttributes[1]) && isset($clothingAttributes[2]) && isset($clothingAttributes[3]) && isset($clothingAttributes[4])) {
					$clothings[] = new Clothing(
						(int)$clothingAttributes[0],
						$clothingAttributes[1],
						(int)$clothingAttributes[2],
						$clothingAttributes[3],
						$clothingAttributes[4]
					);
				}
			}

			fclose($file);
			return $clothings;
		}
	}
?>
