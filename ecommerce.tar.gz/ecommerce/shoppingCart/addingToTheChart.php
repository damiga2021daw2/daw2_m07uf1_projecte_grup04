<?php
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);

	//$persister->addingProduct((int)$_POST["id"]);
	echo "<h1>Added to the chart</h1> <br>";
	echo ("<a href=\"/ecommerce/products/\">Back to the catalog</a>");
?>
