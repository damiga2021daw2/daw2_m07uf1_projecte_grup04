<?php
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);
	include_once (__DIR__ . '/../utils/Persistence/FileClothingPersister.php');
	include_once (__DIR__ . '/../utils/Persistence/FileVideogamesPersister.php');


	$persisterClothing = new FileClothingPersister();
	$persisterVideogames = new FileVideogamesPersister();


	$clothings = $persisterClothing->getAllClothing();
	$Videogames = $persisterVideogames->getAllVideogames();

?>

<html>
	<body>
		<h1>Listado de productos</h1>
		<div style="border: 1px black solid;">
			<h2>Clothing products list:</h2>
			<table>
			  <tr>
				<th>#Id</th>
				<th>Name</th>
				<th>Price</th>
				<th>Description</th>
				<th>Textile type</th>
				<th></th>
			  </tr>
			  <?php
				foreach($clothings as $clothing) {
					echo "<tr>";
						echo "<td>".$clothing->id()."</td>";
						echo "<td>".$clothing->name()."</td>";
						echo "<td>".$clothing->price()."</td>";
						echo "<td>".$clothing->description()."</td>";
						echo "<td>".$clothing->textilType()."</td>";
						echo "<td><a href=\"/ecommerce/products/shoppingCart/addingToTheChart.php?id=".$clothing->id()."\">Add to the chart<a/></td>";
					echo "</tr>";
				}
			  ?>
			</table>
		<br>
		
		<h2>Videogaming products list:</h2>
			<table>
			  <tr>
				<th>#Id</th>
				<th>Name</th>
				<th>Price</th>
				<th>Description</th>
				<th>Company</th>
				<th></th>
			  </tr>
			  <?php
				foreach($Videogames as $Videogame) {
					echo "<tr>";
						echo "<td>".$Videogame->id()."</td>";
						echo "<td>".$Videogame->name()."</td>";
						echo "<td>".$Videogame->price()."</td>";
						echo "<td>".$Videogame->description()."</td>";
						echo "<td>".$Videogame->company()."</td>";
						echo "<td><a href=\"/ecommerce/products/shoppingCart/newVideogamesWithOutRedirect.php?id=".$clothing->id()."\">Add to the chart<a/></td>";
					echo "</tr>";
				}
			  ?>
			</table>
		</div><br><br>
		
		<div style="border: 1px black solid;">
			<h2>Chart:</h2>
			<table>
			  <tr>
				<th>#Id</th>
				<th>Name</th>
				<th>Price</th>
				<th>Description</th>
				<th>Company</th>
				<th></th>
			  </tr>
			  <?php
				foreach($Videogames as $Videogame) {
					echo "<tr>";
						echo "<td>".$Videogame->id()."</td>";
						echo "<td>".$Videogame->name()."</td>";
						echo "<td>".$Videogame->price()."</td>";
						echo "<td>".$Videogame->description()."</td>";
						echo "<td>".$Videogame->company()."</td>";
						echo "<td><a href=\"/ecommerce/products/shoppingCart/newVideogamesWithOutRedirect.php?id=".$clothing->id()."\">Add to the chart<a/></td>";
					echo "</tr>";
				}
			  ?>
			</table>
		</div><br><br>
	</body>
</html>
